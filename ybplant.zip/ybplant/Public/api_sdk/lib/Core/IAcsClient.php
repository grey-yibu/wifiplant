<?php

namespace Aliyun\Core;
interface IAcsClient
{
	public function doAction($requst);
}